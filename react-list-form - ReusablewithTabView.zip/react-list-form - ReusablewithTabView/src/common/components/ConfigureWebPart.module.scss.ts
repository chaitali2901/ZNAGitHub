/* tslint:disable */
require("./ConfigureWebPart.module.css");
const styles = {
  container: 'container_f7c71bef',
  title: 'title_f7c71bef',
  description: 'description_f7c71bef',
  button: 'button_f7c71bef'
};

export default styles;
/* tslint:enable */