/* tslint:disable */
require("./DraggableComponent.module.css");
const styles = {
  draggableComponent: 'draggableComponent_98a40df4',
  isDragging: 'isDragging_98a40df4',
  toolbar: 'toolbar_98a40df4',
  button: 'button_98a40df4'
};

export default styles;
/* tslint:enable */