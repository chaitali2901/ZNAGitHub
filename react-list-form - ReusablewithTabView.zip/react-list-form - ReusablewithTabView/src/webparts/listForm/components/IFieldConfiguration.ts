export interface IFieldConfiguration {
  key: string;
  fieldName: string;
}
