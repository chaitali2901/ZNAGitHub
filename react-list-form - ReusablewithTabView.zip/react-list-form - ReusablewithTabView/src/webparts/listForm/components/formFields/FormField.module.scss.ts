/* tslint:disable */
require("./FormField.module.css");
const styles = {
  formField: 'formField_3f2aedbe',
  label: 'label_3f2aedbe',
  controlContainerDisplay: 'controlContainerDisplay_3f2aedbe'
};

export default styles;
/* tslint:enable */