/* tslint:disable */
require("./SPFormField.module.css");
const styles = {
  dropDownFormField: 'dropDownFormField_2427d638',
  dateFormField: 'dateFormField_2427d638',
  unsupportedFieldMessage: 'unsupportedFieldMessage_2427d638'
};

export default styles;
/* tslint:enable */