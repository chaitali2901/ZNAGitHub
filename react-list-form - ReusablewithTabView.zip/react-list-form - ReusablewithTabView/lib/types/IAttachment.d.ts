export interface IAttachment {
    AttachmentId?: string;
    FileName: string;
    FileBuffer?: ArrayBuffer;
    RedirectUrl?: string;
}
//# sourceMappingURL=IAttachment.d.ts.map