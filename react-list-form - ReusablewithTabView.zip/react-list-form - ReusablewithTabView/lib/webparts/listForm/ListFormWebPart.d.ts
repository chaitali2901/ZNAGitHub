import { BaseClientSideWebPart } from "@microsoft/sp-webpart-base";
import { IPropertyPaneConfiguration } from "@microsoft/sp-property-pane";
import { IListFormWebPartProps } from './IListFormWebPartProps';
export default class ListFormWebPart extends BaseClientSideWebPart<IListFormWebPartProps> {
    private listService;
    private cachedLists;
    protected onInit(): Promise<void>;
    render(): void;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
    private loadLists;
    private onListChange;
    private updateField;
    private formSubmitted;
}
//# sourceMappingURL=ListFormWebPart.d.ts.map