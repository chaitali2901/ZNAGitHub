import * as React from 'react';
import { IDatePickerProps } from 'office-ui-fabric-react/lib/DatePicker';
import { IFieldSchema } from '../../../../common/services/datatypes/RenderListData';
export interface IDateFormFieldProps extends IDatePickerProps {
    locale: string;
    fieldSchema: IFieldSchema;
    valueChanged(newValue: any): void;
    value: any;
}
export interface IDateFormFieldState {
    date?: Date;
    hours: number;
    minutes: number;
}
export default class DateFormField extends React.Component<IDateFormFieldProps, IDateFormFieldState> {
    constructor(props: any);
    componentDidUpdate(prevProps: IDateFormFieldProps, prevState: IDateFormFieldState): void;
    render(): JSX.Element;
    private _onSelectDate;
    private _onHoursChanged;
    private _onMinutesChanged;
    private _createComboBoxHours;
    private _createComboBoxMinutes;
}
//# sourceMappingURL=DateFormField.d.ts.map