import * as React from 'react';
import { ISPFormFieldProps } from './SPFormField';
declare const SPFieldTaxonomyEdit: React.SFC<ISPFormFieldProps>;
export default SPFieldTaxonomyEdit;
//# sourceMappingURL=SPFieldTaxonomyEdit.d.ts.map