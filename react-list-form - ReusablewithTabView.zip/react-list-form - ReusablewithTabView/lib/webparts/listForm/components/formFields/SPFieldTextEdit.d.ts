import * as React from 'react';
import { ISPFormFieldProps } from './SPFormField';
declare const SPFieldTextEdit: React.SFC<ISPFormFieldProps>;
export default SPFieldTextEdit;
//# sourceMappingURL=SPFieldTextEdit.d.ts.map