import * as React from 'react';
import { IFieldSchema } from '../../../../common/services/datatypes/RenderListData';
import { WebPartContext } from '@microsoft/sp-webpart-base';
import { IFormFieldProps } from './FormField';
export interface ISPFormFieldProps extends IFormFieldProps {
    extraData?: any;
    fieldSchema: IFieldSchema;
    hideIfFieldUnsupported?: boolean;
    context: WebPartContext;
}
declare const SPFormField: React.SFC<ISPFormFieldProps>;
export default SPFormField;
//# sourceMappingURL=SPFormField.d.ts.map