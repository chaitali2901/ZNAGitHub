import * as React from 'react';
import { ISPFormFieldProps } from './SPFormField';
declare const SPFieldDateEdit: React.SFC<ISPFormFieldProps>;
export default SPFieldDateEdit;
//# sourceMappingURL=SPFieldDateEdit.d.ts.map