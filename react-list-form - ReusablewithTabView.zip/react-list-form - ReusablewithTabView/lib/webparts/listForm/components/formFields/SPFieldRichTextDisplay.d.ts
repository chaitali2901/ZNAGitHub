import * as React from 'react';
import { ISPFormFieldProps } from './SPFormField';
declare const SPFieldRichTextDisplay: React.SFC<ISPFormFieldProps>;
export default SPFieldRichTextDisplay;
//# sourceMappingURL=SPFieldRichTextDisplay.d.ts.map