import * as React from 'react';
import { ISPFormFieldProps } from './SPFormField';
declare const SPFieldUserEdit: React.SFC<ISPFormFieldProps>;
export default SPFieldUserEdit;
//# sourceMappingURL=SPFieldUserEdit.d.ts.map