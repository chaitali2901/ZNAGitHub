import * as React from 'react';
import { IAttachment } from "../../../../types/IAttachment";
import { ControlMode } from '../../../../common/datatypes/ControlMode';
interface IAttachmentProps {
    controlMode: ControlMode;
    value: any;
    valueChanged(newValue: any): void;
}
interface IAttachmentState {
    waitingImageUpload: boolean;
    fileBuffer: any;
    hideDialog: boolean;
    attachments: IAttachment[];
}
export declare class AttachmentRender extends React.Component<IAttachmentProps, IAttachmentState> {
    private inputRef;
    constructor(props: IAttachmentProps);
    componentDidUpdate(prevProps: IAttachmentProps, prevState: IAttachmentState): void;
    render(): JSX.Element;
    private _handleFileSelect;
    private _handleFileInputChange;
    private _renderFilesList;
    private _deleteFileItem;
    private _getFileAsBuffer;
}
export {};
//# sourceMappingURL=AttachmentRender.d.ts.map