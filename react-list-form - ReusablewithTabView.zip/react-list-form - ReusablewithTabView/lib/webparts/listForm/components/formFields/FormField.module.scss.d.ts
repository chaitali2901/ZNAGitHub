declare const styles: {
    formField: string;
    label: string;
    controlContainerDisplay: string;
};
export default styles;
//# sourceMappingURL=FormField.module.scss.d.ts.map