import * as React from 'react';
import { ISPFormFieldProps } from './SPFormField';
declare const SPAttachmentFormFieldEdit: React.SFC<ISPFormFieldProps>;
export default SPAttachmentFormFieldEdit;
//# sourceMappingURL=SPAttachmentFormFieldEdit.d.ts.map