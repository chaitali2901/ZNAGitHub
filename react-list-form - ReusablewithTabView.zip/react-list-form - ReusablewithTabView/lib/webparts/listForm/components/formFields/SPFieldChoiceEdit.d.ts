import * as React from 'react';
import { ISPFormFieldProps } from './SPFormField';
declare const SPFieldChoiceEdit: React.SFC<ISPFormFieldProps>;
export default SPFieldChoiceEdit;
//# sourceMappingURL=SPFieldChoiceEdit.d.ts.map