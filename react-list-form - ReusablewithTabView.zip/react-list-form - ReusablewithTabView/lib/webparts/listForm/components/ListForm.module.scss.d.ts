declare const styles: {
    listForm: string;
    title: string;
    description: string;
    formFieldsContainer: string;
    isDataLoading: string;
    formButtonsContainer: string;
    addFieldToolbox: string;
    addFieldToolboxPlusButton: string;
};
export default styles;
//# sourceMappingURL=ListForm.module.scss.d.ts.map