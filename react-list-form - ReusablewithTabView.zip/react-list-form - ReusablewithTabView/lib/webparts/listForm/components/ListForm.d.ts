import { IListFormProps } from './IListFormProps';
import "@pnp/sp/webs";
import "@pnp/sp/lists/web";
import "@pnp/sp/site-users";
import "@pnp/sp/items";
import { IFieldSchema } from '../../../common/services/datatypes/RenderListData';
/*************************************************************************************
 * React Component to render a SharePoint list form on any page.
 * The list form can be configured to be either a new form for adding a new list item,
 * an edit form for changing an existing list item or a display form for showing the
 * fields of an existing list item.
 * In design mode the fields to render can be moved, added and deleted.
 *************************************************************************************/
export interface IListItem {
    Title: string;
    Key: string;
    Value: string;
    FormType: string;
}
export interface ITabListItem {
    Title: string;
    Value: string;
    Order: number;
    VisibleForGroups: string;
}
export interface ITabFieldListItem {
    TabName: string;
    FieldInternalName: string;
}
export interface ITabStructure {
    TabName: string;
    OrderId: number;
    FieldSchema: IFieldSchema[];
}
declare const _default: __ReactDnd.ContextComponentClass<IListFormProps>;
export default _default;
//# sourceMappingURL=ListForm.d.ts.map