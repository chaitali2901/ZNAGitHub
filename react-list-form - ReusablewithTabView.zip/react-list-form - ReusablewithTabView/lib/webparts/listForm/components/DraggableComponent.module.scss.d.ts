declare const styles: {
    draggableComponent: string;
    isDragging: string;
    toolbar: string;
    button: string;
};
export default styles;
//# sourceMappingURL=DraggableComponent.module.scss.d.ts.map