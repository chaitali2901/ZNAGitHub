import * as React from 'react';
import { IAsyncDropdownProps } from './IAsyncDropdownProps';
import { IAsyncDropdownState } from './IAsyncDropdownState';
export default class AsyncDropdown extends React.Component<IAsyncDropdownProps, IAsyncDropdownState> {
    private selectedKey;
    constructor(props: IAsyncDropdownProps, state: IAsyncDropdownState);
    componentDidMount(): void;
    componentDidUpdate(prevProps: IAsyncDropdownProps, prevState: IAsyncDropdownState): void;
    render(): JSX.Element;
    private loadOptions;
    private onChanged;
}
//# sourceMappingURL=AsyncDropdown.d.ts.map