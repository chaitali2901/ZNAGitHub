export declare class SPHelper {
    static LookupValueToString(value: any | Array<any>): string;
    static LookupValueFromString(value: string): Array<any>;
}
//# sourceMappingURL=SPHelper.d.ts.map