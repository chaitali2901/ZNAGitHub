import * as React from 'react';
import { IWebPartContext } from '@microsoft/sp-webpart-base';
export interface IConfigureWebPartProps {
    webPartContext: IWebPartContext;
    title: string;
    description?: string;
    buttonText?: string;
}
declare const ConfigureWebPart: React.SFC<IConfigureWebPartProps>;
export default ConfigureWebPart;
//# sourceMappingURL=ConfigureWebPart.d.ts.map