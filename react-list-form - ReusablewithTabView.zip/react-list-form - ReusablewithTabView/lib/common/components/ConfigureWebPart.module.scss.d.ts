declare const styles: {
    container: string;
    title: string;
    description: string;
    button: string;
};
export default styles;
//# sourceMappingURL=ConfigureWebPart.module.scss.d.ts.map