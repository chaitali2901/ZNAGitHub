import { SPHttpClient } from '@microsoft/sp-http';
export declare class ListService {
    private spHttpClient;
    constructor(spHttpClient: SPHttpClient);
    getListsFromWeb(webUrl: string): Promise<Array<{
        url: string;
        title: string;
    }>>;
}
//# sourceMappingURL=ListService.d.ts.map