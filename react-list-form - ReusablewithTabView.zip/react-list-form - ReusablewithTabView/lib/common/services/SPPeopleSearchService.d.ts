import { ISPPeopleSearchService } from './ISPPeopleSearchService';
import { IWebPartContext } from '@microsoft/sp-webpart-base';
/**
 * Service implementation to search people in SharePoint
 */
export declare class SPPeopleSearchService implements ISPPeopleSearchService {
    /**
     * Search people from the SharePoint People database
     */
    searchPeople(ctx: IWebPartContext, query: string, principalType: any[], siteUrl?: string): Promise<any[]>;
    resolvePeople(ctx: IWebPartContext, query: string, siteUrl?: string): Promise<any>;
    /**
     * Generates Initials from a full name
     */
    private getFullNameInitials;
    /**
     * Gets the user photo url
     */
    private getUserPhotoUrl;
}
//# sourceMappingURL=SPPeopleSearchService.d.ts.map