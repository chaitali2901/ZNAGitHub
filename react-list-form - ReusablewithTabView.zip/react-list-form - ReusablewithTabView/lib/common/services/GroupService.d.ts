import { SPHttpClient } from '@microsoft/sp-http';
export declare class GroupService {
    private spHttpClient;
    constructor(spHttpClient: SPHttpClient);
    getGroupFromWeb(webUrl: string, groupId: number): Promise<any>;
}
//# sourceMappingURL=GroupService.d.ts.map