import { BaseListViewCommandSet, IListViewCommandSetListViewUpdatedParameters, IListViewCommandSetExecuteEventParameters } from '@microsoft/sp-listview-extensibility';
/**
 * If your command set uses the ClientSideComponentProperties JSON input,
 * it will be deserialized into the BaseExtension.properties object.
 * You can define an interface to describe it.
 */
export interface IEflSpecimenCommandSetProperties {
    sampleTextOne: string;
}
export default class EflSpecimenCommandSet extends BaseListViewCommandSet<IEflSpecimenCommandSetProperties> {
    private _showPanel;
    private _dismissPanel;
    private _renderPanelComponent;
    private panelPlaceHolder;
    onInit(): Promise<void>;
    onListViewUpdated(event: IListViewCommandSetListViewUpdatedParameters): void;
    onExecute(event: IListViewCommandSetExecuteEventParameters): void;
}
//# sourceMappingURL=EflSpecimenCommandSet.d.ts.map