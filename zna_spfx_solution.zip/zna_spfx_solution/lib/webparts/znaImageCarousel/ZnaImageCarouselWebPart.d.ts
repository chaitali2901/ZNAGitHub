import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
export interface IZnaImageCarouselWebPartProps {
    description: string;
}
export default class ZnaImageCarouselWebPart extends BaseClientSideWebPart<IZnaImageCarouselWebPartProps> {
    render(): void;
    protected onDispose(): void;
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=ZnaImageCarouselWebPart.d.ts.map