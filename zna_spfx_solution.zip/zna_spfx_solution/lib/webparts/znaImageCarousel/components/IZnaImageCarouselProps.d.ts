export interface IZnaImageCarouselProps {
    description: string;
}
//# sourceMappingURL=IZnaImageCarouselProps.d.ts.map