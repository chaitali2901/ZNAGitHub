import { BaseDialog, IDialogConfiguration } from '@microsoft/sp-dialog';
import "@pnp/sp/webs";
import "@pnp/sp/lists";
export default class DialogControl extends BaseDialog {
    itemDialogContent: Array<string>;
    otherParam: string;
    paramFromDailog: string;
    render(): void;
    getConfig(): IDialogConfiguration;
    protected onAfterClose(): void;
}
//# sourceMappingURL=DialogControl.d.ts.map