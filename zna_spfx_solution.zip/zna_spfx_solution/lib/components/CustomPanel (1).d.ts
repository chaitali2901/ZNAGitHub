import * as React from 'react';
import { WebPartContext } from '@microsoft/sp-webpart-base';
import "@pnp/sp/webs";
import "@pnp/sp/lists/web";
import "@pnp/sp/items";
import "@pnp/sp/attachments";
import "@pnp/sp/folders";
import "@pnp/sp/files";
export interface ICustomPanelState {
    saving: boolean;
    PolicyNumber: string;
    EffDateOfPol: Date;
    Producer: string;
    AddIPrem: string;
    ReturnPrem: string;
    InsuredName: string;
    InsuredAddress: string;
    ProducerName: string;
    ProducerAddress: string;
}
export interface ICustomPanelProps {
    onClose: () => void;
    isOpen: boolean;
    currentTitle: string;
    itemId: any;
    listId: string;
    context: WebPartContext;
}
export default class CustomPanel extends React.Component<ICustomPanelProps, ICustomPanelState> {
    componentDidMount1(base64data: any): Promise<void>;
    getAttachment(itemID: number, listId: string): Promise<any>;
    private editedTitle;
    private _policyNumber;
    private _effDateOfPol;
    private _producer;
    private _addIPrem;
    private _returnPrem;
    private _insuredName;
    private _insuredAddress;
    private _producerName;
    private _producerAddress;
    private handleChange;
    private formatDate;
    constructor(props: ICustomPanelProps, state: ICustomPanelState);
    private _onTitleChanged;
    private _onCancel;
    private itemCount;
    private fileCount;
    private attachmentArry;
    private finalArray;
    private _onSave;
    private proceesAttchemnt;
    render(): React.ReactElement<ICustomPanelProps>;
}
//# sourceMappingURL=CustomPanel (1).d.ts.map