import * as React from 'react';	
import { escape } from '@microsoft/sp-lodash-subset';  
//import { Dialog, DialogContent, DialogType, DialogFooter } from 'office-ui-fabric-react/lib/Dialog';  
import {BaseDialog, IDialogConfiguration } from '@microsoft/sp-dialog';
import { PrimaryButton, DefaultButton } from 'office-ui-fabric-react/lib/Button';  
import { autobind } from 'office-ui-fabric-react';  
import { sp } from "@pnp/sp";  
import "@pnp/sp/webs";  
import "@pnp/sp/lists"; 


// export interface IDialogControlState {	    
//     hideDialog: boolean;
// }	

// export interface IDialogControlProps {	  
//     //onClose: () => void;	
//     //hideDialog: boolean;	
//     //currentTitle: string;	    
//     itemId: any;	   
//     //listId: string;	
// //    context: WebPartContext;
// }	
 
  

export default class DialogControl extends BaseDialog {  
    public itemDialogContent:Array<string> = [];  
    public otherParam: string;  
    public paramFromDailog:string; 
     

    
    public render(): void {  
       var html :string = ""; 
       html +=  '<div style="padding: 30px;">'; 
       html +=  '<div style="font-weight:bold">List Of Forms</div><br/><br/>'; 
       for(let i=0; i<this.itemDialogContent.length;i++)
       {
            html+=  '<p><span>' + this.itemDialogContent[i] +'</span></p>';
       }
       
       html +=  '<br/><br/><br/><br/><input type="button" id="OkButton"  value="Ok">';
       html +=  '</div>';  
       this.domElement.innerHTML += html;
        this.domElement.querySelector('#OkButton').addEventListener('click', () => {
            this.close();
        });
    }

        public getConfig() : IDialogConfiguration{
            return {
                isBlocking : false
            };
        }

        protected onAfterClose(): void {  
            super.onAfterClose();       
          } 
      }
      
      

//  public _showDialog = (): void => {  
//     this.setState({ hideDialog: false });  
//   }  
  
//   private _closeDialog = (): void => {  
//     this.setState({ hideDialog: true });  
//     this.render();  
//   }  
  
