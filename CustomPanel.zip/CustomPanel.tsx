import * as React from 'react';	
import { TextField, DefaultButton, PrimaryButton, DialogFooter, Panel, Spinner} from "office-ui-fabric-react";	
import { sp } from "@pnp/sp";	
import { Dropdown, IDropdownOption } from 'office-ui-fabric-react/lib/Dropdown';
//import { DatePicker, DayOfWeek, IDatePickerStrings, mergeStyleSets } from 'office-ui-fabric-react'; 
import { DatePicker, DayOfWeek, IDatePickerStrings,mergeStyleSets } from 'office-ui-fabric-react'; 
import {
    SPHttpClient,
    ISPHttpClientOptions,
    SPHttpClientResponse,
  } from "@microsoft/sp-http";
import { WebPartContext } from '@microsoft/sp-webpart-base';
import { HttpClientResponse, IHttpClientOptions } from '@microsoft/sp-http';


import { IItem } from "@pnp/sp/items/types";
import "@pnp/sp/webs";
import "@pnp/sp/lists/web";
import "@pnp/sp/items";
import "@pnp/sp/attachments";
import "@pnp/sp/folders";
import "@pnp/sp/files";

import DialogControl from "./DialogControl";
//import DialogControlProps
//import { Body } from 'react-bootstrap/lib/Panel';

const DayPickerStrings: IDatePickerStrings = {
    months: [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ],
  
    shortMonths: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],  
    days: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],  
    shortDays: ['S', 'M', 'T', 'W', 'T', 'F', 'S'],  
    goToToday: 'Go to today',
    prevMonthAriaLabel: 'Go to previous month',
    nextMonthAriaLabel: 'Go to next month',
    prevYearAriaLabel: 'Go to previous year',
    nextYearAriaLabel: 'Go to next year',
    closeButtonAriaLabel: 'Close date picker',
    //monthPickerHeaderAriaLabel: '{0}, select to change the year',
    //yearPickerHeaderAriaLabel: '{0}, select to change the month',
  };
  
  const controlClass = mergeStyleSets({
    control: {
      margin: '0 0 15px 0',
      maxWidth: '300px',
    },
  });

export interface ICustomPanelState {	    
    saving: boolean;	
    PolicyNumber:string;
    EffDateOfPol:Date;
    Producer:string;
    AddIPrem:string;
    ReturnPrem:string;
    InsuredName:string;
    InsuredAddress:string;
    ProducerName:string;
    ProducerAddress:string;
}	

export interface ICustomPanelProps {	  
    onClose: () => void;	
    isOpen: boolean;	
    currentTitle: string;	    
    itemId: any;	
    itemFormNo: any;	
    itemFormTitle: any,   
    listId: string;	
    context: WebPartContext;
}	

export default class CustomPanel extends React.Component<ICustomPanelProps, ICustomPanelState> {	      
    
    public async componentDidMount1(base64data:any){
        // var obj={};
        // for (let index = 0; index < base64data.length; index++) {
        //     obj["file"+index]=base64data[index];
        // }

        var obj={};
        for (let index = 0; index < base64data.length; index++) {
            var temp=index+1;
            var count=base64data.length;
            if(index == 0){
                obj["fileCount"]= count.toString();
                obj["file"+temp]=base64data[index];
            }
            else{
                obj["file"+temp]=base64data[index];
            }
        }

        const headers : Headers= new Headers();   
        headers.append("Content-Type", "application/json");     
        const requestOptions : IHttpClientOptions={
           headers,            
            body:JSON.stringify(obj)
            //body: `{ "firstFile": "${base64data[0]}","secondFile": "${base64data[1]}" }`
            //body: `{ "firstFile": "{base64data}","secondFile": "${base64data}" }`
        };
       
        const httpResponse:HttpClientResponse= await this.props.context.httpClient.post(
            'https://azdynamicmerge.azurewebsites.net/api/DocumentsMerge?code=fCfJQtwa06HruwnLCH43Rre1OSm83ib7q0nf7cx456OeYacAiazhZw==',
            SPHttpClient.configurations.v1,
            requestOptions      
            );
        
        var byte_numbers = await httpResponse.arrayBuffer();        
        var byte_array = new Uint8Array(byte_numbers);
        var file_blob = new Blob([byte_array], {​​type: "application/vnd.openxmlformatsofficedocument.wordprocessing" }​​);
        var file = new File([file_blob], "Document1.docx", {type: "application/vnd.openxmlformatsofficedocument.wordprocessing", lastModified: Date.now()});
        console.log(file);
        sp.web.getFolderByServerRelativeUrl("/sites/EnvironmentalFormsLibrary/EFLDocuments")
        .files.addChunked(file.name,file)
        .then(({file}) => file.getItem()). then((item:any) => {
            console.log("File Uploaded");
            return item.update({
                PolicyNumber : this.state.PolicyNumber,
                Producer : this.state.Producer,
                EffDateOfPol : this.state.EffDateOfPol,
                AddIPrem : this.state.AddIPrem,
                ReturnPrem : this.state.ReturnPrem,
                InsuredName : this.state.InsuredName,
                InsuredAddress : this.state.InsuredAddress,
                ProducerName : this.state.ProducerName,
                ProducerAddress : this.state.ProducerAddress
            }).then((myupdate) => {
                console.log(myupdate);
            });
        },
        e=>{
            console.log("Failed to upload the File");
        });

        // //Call Modal Dialog
        // let dialogContent = [] ;
        // const dialog : DialogControl = new DialogControl();
        // for (let i = 0; i < this.props.itemFormNo.length; i++) {
        //     for(let j=0; j < this.props.itemFormTitle.length; j++){
        //         if(i==j)
        //         {
        //             dialogContent.push(this.props.itemFormNo[i] + " " + this.props.itemFormTitle[j]);
        //         }
        //     }
        // }

        // dialog.itemDialogContent = dialogContent;
        // dialog.show();
    }

    public async getAttachment(itemID: number,listId:string): Promise<any> {
        var httpClientOptions: ISPHttpClientOptions = {};
        httpClientOptions.headers = { Accept: "application/json;odata=nometadata", "odata-version": "" };
        //return this._readListId(this._lstAttendeesRegistered).then((listId: string) => {
          const url = this.props.context.pageContext.web.absoluteUrl + `/_api/web/lists(guid'${listId}')/items?$select=Attachments&$expand=AttachmentFiles`;//&$filter=Person/EMail eq '${strEmail}'`;
          return new Promise<any[]>((resolve: (result: any[]) => void, reject: (error: any) => void): void => {
            this.props.context.spHttpClient.get(url, SPHttpClient.configurations.v1, httpClientOptions).then((response: SPHttpClientResponse): Promise<{ value: any[] }> => { return response.json() }).then((docData: { value: any[] }): void => { resolve(docData.value); }, (error: any): void => { reject(error); });
          });
        //});
      }

    private editedTitle: string = null;	
    //
    private _policyNumber: string = "";
    private _effDateOfPol: Date = null;
    //private _expDateOfPol: string = "";
   // private _effDateOfEnd: string = "";
    private _producer: string = "";
    private _addIPrem: string = "";
    private _returnPrem: string = "";
    private _insuredName: string = "";
    private _insuredAddress: string = "";
    private _producerName: string = "";
    private _producerAddress: string = "";
    //

    // private handleChange(value: Date) {
    //     this.setState({EffDateOfPol: value});        
    //     //this._policyNumber = value;
    // }

    
    private formatDate = (value : Date) : string => {
        return value.getDate() + "/" + (value.getMonth()+1) + "/" + value.getFullYear();
    };

    constructor(props: ICustomPanelProps, state: ICustomPanelState) {	        
        super(props);	        
        this.state = {	           
            saving: false,
            PolicyNumber:"",
            EffDateOfPol:null,
            Producer:"",
            AddIPrem:"",
            ReturnPrem:"",
            InsuredName:"",
            InsuredAddress:"",
            ProducerName:"",
            ProducerAddress:"",           
        };	   
    }    
    
    private _onTitleChanged(title: string) {this.editedTitle = title;}	
    private _onCancel() { this.props.onClose();	}	
    
    private itemCount = 0;
    private fileCount = 0;
    private attachmentArry=[];
    private finalArray=[];
    private    _onSave = async()=> {	        
        this.setState({ saving: true });	 
        let attachmentsArr : Array<any> = [] ;
        
        //this.props.itemId.forEach(element => {
        for (let index = 0; index < this.props.itemId.length; index++) {
            const element = this.props.itemId[index];
            const item: IItem = sp.web.lists.getByTitle("Environmental Forms Library").items.getById(element);                
            const responseAttachments = await item.attachmentFiles.get();                
            //responseAttachments.forEach(attachmentItem => {
            for(let i=0; i<responseAttachments.length;i++)
            {
                let attachmentItem = responseAttachments[i];
                const attachment = await item.attachmentFiles.getByName(attachmentItem.FileName).getBlob();
                this.attachmentArry.push(attachment);
            }                                        
        }
        //console.log(attachmentsArr);
        await this.proceesAttchemnt(); 

        //Call Modal Dialog
        let dialogContent = [] ;
        const dialog : DialogControl = new DialogControl();
        for (let i = 0; i < this.props.itemFormNo.length; i++) {
            for(let j=0; j < this.props.itemFormTitle.length; j++){
                if(i==j)
                {
                    dialogContent.push(this.props.itemFormNo[i] + " " + this.props.itemFormTitle[j]);
                }
            }
        }

        dialog.itemDialogContent = dialogContent;
        dialog.show();
        
        
    }

    private proceesAttchemnt=async()=>{
        if(this.attachmentArry.length > this.itemCount){

            let attachment=this.attachmentArry[this.itemCount];
            var reader = new FileReader();
            var self=this;
            reader.readAsDataURL(attachment); 
            
            var base64data;                            
            reader.onloadend = function() {                
                base64data = reader.result;                 
                //base64data='{ "$content-type": "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ' + '"$content": "'+ base64data.toString().split('data:application/octet-stream;base64,')[1] + '"' + '}';
                base64data=base64data.toString().split('data:application/octet-stream;base64,')[1];  
                self.finalArray.push(base64data);
                self.itemCount++;
                self.proceesAttchemnt();
                //attachmentsArr.push(base64data);
            }
        }
        else{
            this.componentDidMount1(this.finalArray)
        }
    }

    public render(): React.ReactElement<ICustomPanelProps> {	        
        let { isOpen, currentTitle } = this.props;	        
        return (	            
        <Panel isOpen={isOpen}>	                
                <h2>Auto Populate</h2>
                <hr style={{ height:"10px",background:"blue"}}></hr>	               
                <TextField  label="Policy Number" placeholder="Enter Policy No(2-3A- 7N 2N)" value={this._policyNumber} onChanged={(vals) => { this._policyNumber = vals; this.setState({PolicyNumber:vals}); }} />
                <DatePicker
                className={controlClass.control}
                strings={DayPickerStrings}
                label="Eff. Date of Pol"
                placeholder="Select a date..."
                ariaLabel="Select a date"
                value = {this._effDateOfPol}
                //onChange={(event) => this.handleChange(event)}
                onSelectDate={ date => this.setState({ EffDateOfPol: date }) } 
                //formatDate = {this.formatDate}
            />	
            <DatePicker
                className={controlClass.control}
                strings={DayPickerStrings}
                label="Exp. Date of Pol"
                placeholder="Select a date..."
                ariaLabel="Select a date"
               // onChange={(event) => this.handleChange(event)}
            />
            <DatePicker
                className={controlClass.control}
                strings={DayPickerStrings}
                label="Eff. Date of End"
                placeholder="Select a date..."
                ariaLabel="Select a date"
            /> 
                <TextField  label="Producer" placeholder="Enter Producer (8N)" onChanged={(vals) => { this._producer = vals;  this.setState({Producer:vals});}}/>
                <TextField  label="Add 'I Prem" placeholder="Enter Add 'I Prem" onChanged={(vals) => { this._addIPrem = vals;  this.setState({AddIPrem:vals});}}/> 
                <TextField  label="Return Prem" placeholder="Enter return Prem" onChanged={(vals) => { this._returnPrem = vals;  this.setState({ReturnPrem:vals});}}/> 
                <h2>Named Insured and Mailing Address</h2>
                <hr></hr>
                <TextField  label="Name" placeholder="Enter Insured Name" onChanged={(vals) => { this._insuredName = vals;  this.setState({InsuredName:vals});}}/>
                <TextField  label="Address" placeholder="Enter Insured Address" onChanged={(vals) => { this._insuredAddress = vals;  this.setState({InsuredAddress:vals});}}/>
                <h2>Producer</h2>
                <hr></hr>
                <TextField  label="Name" placeholder="Enter Producer Name" onChanged={(vals) => { this._producerName = vals;  this.setState({ProducerName:vals});}}/>
                <TextField  label="Address" placeholder="Enter Producer Address" onChanged={(vals) => { this._producerAddress = vals;  this.setState({ProducerAddress:vals});}}/>
                <DialogFooter>	
                    <DefaultButton text="Cancel" onClick={this._onCancel} />
                    <PrimaryButton text="Save" onClick={() => this._onSave()} />	
                </DialogFooter>	           
         </Panel>	       
        );
    }
}


